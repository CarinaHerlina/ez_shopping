from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from bs4 import BeautifulSoup
from pymongo import MongoClient
from datetime import date
import re
import json

client = MongoClient("mongodb+srv://ezg:zaghzjdb@cluster0-cqjyv.azure.mongodb.net/test?retryWrites=true&w=majority")
db = client['foods_db']
collection = db['foods_collection']
print('DB Connected :D')
all_items = {}

fin = open('list.txt', 'r')
needed_items = []
for i in fin.readlines():
    needed_items.append(i.strip())

# get the website
options = Options()
options.add_argument('--headless')
options.add_argument('--ignore-certificate-errors')
options.add_argument('--ignore-ssl-errors')
driver = webdriver.Chrome("chromedriver.exe", chrome_options=options)

for item in needed_items:
    print('Scraping %s' %(item))

    # check if it is available on the database
    res = collection.find_one({'name': item})
    # if res != None:
    #    continue

    driver.get("https://mygrocerydeals.com/deals?utf8=%E2%9C%93&authenticity_token=zPM%2B64IXAaB9SKCLxItI0s%2FlCqi8kmBrvOtocO%2F9C3uFTKYdmhrnRj45F8GVYa5%2FIq9EDTQIJBFk%2Fh5IrME10A%3D%3D&remove%5B%5D=chains&remove%5B%5D=categories&remove%5B%5D=collection&remove%5B%5D=collection_id&q=" + item + "&supplied_location=85281&latitude=33.4366655&longitude=-111.9403254")
    content = driver.page_source
    soup = BeautifulSoup(content, features='lxml')

    item_prices = {}

    for a in soup.findAll('div', attrs={'class': 'container-tile'}):
        price = a.find('span', attrs={'class': 'pricetag'})
        if price == None:
            continue

        item_price = price.text
        try:
            item_price = float( re.findall("\d+\.\d+", item_price)[0] )
        except:
            continue
        store_name = a.find('p', attrs={'class': 'deal-storename'}).text
        item_prices[store_name] = item_price
    
    collection.insert_one({
        'name': item, 
        'date': date.today().__str__(),
        'prices': item_prices
    })


    all_items[item] = {
        'name': item, 
        'date': date.today().__str__(),
        'prices': item_prices
    }


json.dump(all_items, open('output.txt', 'w'))