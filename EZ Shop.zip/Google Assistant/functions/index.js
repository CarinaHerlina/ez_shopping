// Copyright 2016, Google, Inc.
// Licensed under the Apache License, Version 2.0 (the 'License');
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an 'AS IS' BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

'use strict';

const {dialogflow} = require('actions-on-google');
const functions = require('firebase-functions');

const app = dialogflow({debug: true});

function intersection() {
	var result = [];
  var lists;
  
  if(arguments.length === 1) {
  	lists = arguments[0];
  } else {
  	lists = arguments;
  }
  
  for(var i = 0; i < lists.length; i++) {
  	var currentList = lists[i];
  	for(var y = 0; y < currentList.length; y++) {
    	var currentValue = currentList[y];
      if(result.indexOf(currentValue) === -1) {
        var existsInAll = true;
        for(var x = 0; x < lists.length; x++) {
          if(lists[x].indexOf(currentValue) === -1) {
            existsInAll = false;
            break;
          }
        }
        if(existsInAll) {
          result.push(currentValue);
        }
      }
    }
  }
  return result;
}

app.intent('make_name', (conv, {Grocery, Grocery1, Grocery11, Grocery2, Grocery21}) => {
  var all_items = {"apple": {"name": "apple", "date": "2019-09-21", "prices": {"Safeway": 0.99, "Food City": 0.49, "Fry's Food & Drug": 0.99, "El Super": 0.89, "Albertsons": 1.97, "Sprouts": 2.98, "Bashas'": 0.99, "Whole Foods": 2.69}}, "banana": {"name": "banana", "date": "2019-09-21", "prices": {"El Super": 2.99}}, "orange": {"name": "orange", "date": "2019-09-21", "prices": {"El Super": 0.99, "Albertsons": 0.67, "Food City": 0.77, "Smart & Final": 3.99}}, "bread": {"name": "bread", "date": "2019-09-21", "prices": {"Sprouts": 3.99, "El Super": 1.97, "Bashas'": 3.49, "Smart & Final": 2.99, "Albertsons": 2.29, "Fry's Food & Drug": 3.99, "Safeway": 1.99, "Walmart Supercenter": 2.48, "Food City": 1.99}}, "egg": {"name": "egg", "date": "2019-09-21", "prices": {"El Super": 2.27, "Sprouts": 3.99, "Safeway": 3.99, "Bashas'": 2.19, "Whole Foods": 4.29, "Albertsons": 5.0}}, "milk": {"name": "milk", "date": "2019-09-21", "prices": {"Bashas'": 1.69, "Smart & Final": 2.75, "Safeway": 3.99, "Sprouts": 4.99, "Fry's Food & Drug": 3.99, "Albertsons": 6.0, "Target": 3.99, "El Super": 3.0, "Whole Foods": 4.99}}, "carrot": {"name": "carrot", "date": "2019-09-21", "prices": {"Bashas'": 1.99, "El Super": 0.99}}, "corn": {"name": "corn", "date": "2019-09-21", "prices": {"El Super": 0.99, "Bashas'": 0.79}}, "potato": {"name": "potato", "date": "2019-09-21", "prices": {"Food City": 0.77, "Fry's Food & Drug": 2.99, "Sprouts": 0.88, "El Super": 1.99}}, "chicken": {"name": "chicken", "date": "2019-09-21", "prices": {"El Super": 1.59, "Bashas'": 0.99, "Fry's Food & Drug": 0.99, "Food City": 0.97, "Smart & Final": 0.79, "Sprouts": 6.99, "Safeway": 1.47}}, "beef": {"name": "beef", "date": "2019-09-21", "prices": {"Fry's Food & Drug": 3.49, "Safeway": 1.97, "El Super": 1.99, "Sprouts": 5.99, "Whole Foods": 4.99, "Albertsons": 3.99, "Bashas'": 2.97}}, "salmon": {"name": "salmon", "date": "2019-09-21", "prices": {"Bashas'": 3.99, "Sprouts": 8.99}}, "cheese": {"name": "cheese", "date": "2019-09-21", "prices": {"Fry's Food & Drug": 10.0, "Trader Joe's": 9.99, "Bashas'": 3.99, "Safeway": 4.99, "Sprouts": 6.0, "Walgreens": 4.0, "El Super": 3.27}}, "yogurt": {"name": "yogurt", "date": "2019-09-21", "prices": {"El Super": 1.99, "Target": 5.0, "Safeway": 10.0, "Sprouts": 0.77, "Albertsons": 10.0, "Bashas'": 0.99}}, "ice cream": {"name": "ice cream", "date": "2019-09-21", "prices": {"Fry's Food & Drug": 3.49, "Walgreens": 5.49, "Bashas'": 2.99, "Safeway": 7.0, "CVS/pharmacy": 12.0, "El Super": 3.99, "Albertsons": 6.0, "Trader Joe's": 2.99}}, "chips": {"name": "chips", "date": "2019-09-21", "prices": {"Fry's Food & Drug": 3.99, "Target": 5.0, "Bashas'": 1.99, "CVS/pharmacy": 5.0, "Albertsons": 1.97, "El Super": 1.77, "Safeway": 0.99, "Food City": 2.49, "Trader Joe's": 2.49, "Sprouts": 2.99, "Walgreens": 4.0, "Smart & Final": 2.99}}, "coffee": {"name": "coffee", "date": "2019-09-21", "prices": {"El Super": 5.99, "CVS/pharmacy": 5.99, "Safeway": 5.99, "Bashas'": 6.99, "Walgreens": 5.99, "Fry's Food & Drug": 5.99, "Albertsons": 14.99, "Target": 9.99}}, "cola": {"name": "cola", "date": "2019-09-21", "prices": {"Walgreens": 6.0, "Fry's Food & Drug": 2.79, "Albertsons": 11.0, "CVS/pharmacy": 11.0, "El Super": 5.99, "Bashas'": 5.0, "Safeway": 5.0}}, "cereal": {"name": "cereal", "date": "2019-09-21", "prices": {"Safeway": 1.99, "El Super": 3.49, "Fry's Food & Drug": 1.49, "Bashas'": 1.69, "CVS/pharmacy": 1.99, "Albertsons": 2.97, "Smart & Final": 1.99, "Walgreens": 5.0}}, "kiwi": {"name": "kiwi", "date": "2019-09-21", "prices": {}}, "pepper": {"name": "pepper", "date": "2019-09-21", "prices": {}}, "cabbage": {"name": "cabbage", "date": "2019-09-21", "prices": {"Trader Joe's": 3.99}}, "green beans": {"name": "green beans", "date": "2019-09-21", "prices": {"Safeway": 0.99}}, "ground beef": {"name": "ground beef", "date": "2019-09-21", "prices": {"Fry's Food & Drug": 3.49, "Safeway": 2.99, "El Super": 4.59, "Bashas'": 3.47, "Walgreens": 2.49, "Sprouts": 3.99}}};

  if (Grocery === "shutup") {
    conv.close("No, you shut up!");
  }
  else {
    var needed_items = [];
    var len = 0;

    if (all_items.hasOwnProperty(Grocery)) {
      needed_items.push(Grocery.toString());
      len = len + 1;
    }
    if (all_items.hasOwnProperty(Grocery1)) {
      needed_items.push(Grocery1.toString());
      len = len + 1;
    }
    if (all_items.hasOwnProperty(Grocery11)) {
      needed_items.push(Grocery11.toString());
      len = len + 1;
    }
    if (all_items.hasOwnProperty(Grocery2)) {
      needed_items.push(Grocery2.toString());
      len = len + 1;
    }
    if (all_items.hasOwnProperty(Grocery21)) {
      needed_items.push(Grocery21.toString());
      len = len + 1;
    }

    
    var stores = [];
    var i = -1;
    for(var nitem=0; nitem < needed_items.length; nitem++) {
      stores.push([]);
      i = i + 1;
      
      for (var st in all_items[needed_items[nitem]]['prices']) {
        stores[i].push(st);
      }
    }

    var every_Store = intersection(stores);
    var min_price = 1000;
    var min_store = '';
    var max_price = -1000;

    for (var store=0; store<every_Store.length; store++) {
      // get all needed item prices
      var sum = 0;

      for(var nitem=0; nitem<needed_items.length; nitem++) {
        // plus price in that store
        sum = sum + all_items[ needed_items[nitem] ]['prices'][ every_Store[store] ];
      }

      if (sum < min_price) {
        min_price = sum;
        min_store = store;
      }
      if (sum > max_price) {
        max_price = sum;
      }
    }
    var savi = max_price - min_price;
    conv.close('You can buy it from ' + every_Store[min_store] + ' with the total price of $' + min_price + '. Your total saving is $' + savi.toFixed(2));
  }

});

exports.dialogflowFirebaseFulfillment = functions.https.onRequest(app);
